

var playground = document.getElementById('px-render');

var canvas;

var ratio = 150 / 830;

var count = 0;
var raf;


var renderer = PIXI.autoDetectRenderer(436, 653, {transparent:true, antialias:true});
renderer.autoResize = true;
var tp, preview;
var displacementSprite,
	displacementFilter,
	stage;

function setScene(url){
			playground.appendChild(renderer.view);

	        stage = new PIXI.Container();

	        tp = PIXI.Texture.fromImage(url);
	        preview = new PIXI.Sprite(tp);
          
          preview.width = renderer.width;
          preview.height = renderer.height;
	        preview.anchor.x = 0;
	    
	        displacementSprite = PIXI.Sprite.fromImage('https://comfy.moe/fderbl.png');
	        displacementSprite.texture.baseTexture.wrapMode = PIXI.WRAP_MODES.REPEAT;

	       	displacementFilter = new PIXI.filters.DisplacementFilter(displacementSprite);

	        displacementFilter.scale.x = 2100;
displacementFilter.scale.y = 1200;
displacementSprite.scale.set(0.7);
displacementSprite.anchor.set(0.7);


	        stage.addChild(displacementSprite);

	        stage.addChild(preview);

			animate();
}

function removeScene(){
	cancelAnimationFrame(raf);
	stage.removeChildren();
	stage.destroy(true);
	playground.removeChild(canvas);
}


function animate() {
    raf = requestAnimationFrame(animate);
            
    displacementSprite.x = count*10;
	displacementSprite.y = count*10;

	count += 0.05;

    stage.filters = [displacementFilter];

    renderer.render(stage);

    canvas = playground.querySelector('canvas');
}

setScene('https://comfy.moe/jislfp.jpg');


    scrolldist = $(document).scrollTop();
    scrolldist = scrolldist / 80 + 8;


TweenMax.to(displacementFilter.scale, 3, {delay: 0.9, x: scrolldist, y: scrolldist, ease: Expo.easeOut });




$(document).scroll(function(){

    scrolldist = $(document).scrollTop();
    scrolldist = scrolldist / 80 + 8;

    
TweenMax.to(displacementFilter.scale, 10, { x: scrolldist, y: scrolldist, ease: Expo.easeOut });

    
    

});


 $('document').ready(function() {
    $(document).scroll(function(){
      if (document.documentElement.clientHeight + $(window).scrollTop() >= $(document).height()) {
        $(document).scrollTop(0);
      }
    });
  });


$(".portfolio").mouseenter(function(){
    
$(".line").css("width","116px");
    
    
});

$(".portfolio").mouseleave(function(){
    
$(".line").css("width","0px");
    
    
});




$(document).ready(function() {  
    $("body").niceScroll({
    cursorcolor: "#fff600",
    cursoropacitymin: 1, 
    cursoropacitymax: 1, 
    cursorwidth: "14px", 
    cursorborder: "0px solid #fff",
    cursorborderradius: "0px",
    background: "#3d33d1",
        railpadding: { top: 6, right: 6, left: 6, bottom: 6 },
        enabletranslate3d: false,
    });
    
  
    
});  



     
    