
<!-- 
document.writeln(" <img class=\"flag fadein\" src=\"flag.svg\">  "); 
document.writeln("  "); 
document.writeln(" <img class=\"portfolio fadein\" src=\"portfolio.svg\">  "); 
document.writeln(" <span class=\"line\" class=\"fadein\"></span>     "); 
document.writeln(" <a href=\"mailto:itsgrassii@gmail.com\" ><img class=\"link first\" src=\"link-01.svg\"></a> "); 
document.writeln("  "); 
document.writeln(" <a href=\"http://www.youtube.com/c/grassiix\" ><img class=\"link\" src=\"link-03.svg\"></a> "); 
document.writeln("  "); 
document.writeln(" <a href=\"http://www.twitter.com/gr_ssii\" ><img class=\"link\" src=\"link-04.svg\"> </a> "); 
document.writeln("  "); 
document.writeln(" <a href=\"http://www.steamcommunity.com/id/grassii\" ><img class=\"link\" src=\"link-02.svg\"></a> "); 
document.writeln("  "); 
document.writeln(" <a href=\"http://www.instagram.com/gr_ssii\" ><img class=\"link\" src=\"link-05.svg\"></a>    "); 
document.writeln("      ");
document.writeln(" <a href=\"http://www.soundcloud.com/grxssii/likes\" ><img class=\"link last\" src=\"link-06.svg\"></a>    "); 
document.writeln("      "); 
document.writeln(" <div id=\"px-render\" ></div> "); 
document.writeln("  "); 
document.writeln(" <img class=\"spinner\" src=\"circley.svg\"> ");
 // -->

